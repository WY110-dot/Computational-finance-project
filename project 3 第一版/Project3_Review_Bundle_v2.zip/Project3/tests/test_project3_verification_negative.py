"""Negative unit tests for Project 3 verification harness.

Ensures that the verifier strictly rejects:
1. P5 quarantine violation (injected 2025 row into diagnostics/daily_correlations.csv).
2. Reconciliation violation (tampered monthly fee sum != ledger fees sum).
3. Freeze manifest tampering (tampered frozen script hash).
4. Missing required outputs (deleted factors_long.csv or coverage.csv).
5. Report trace discrepancy (tampered value in report_trace.csv).
"""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys
import tempfile
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from verify_project3 import (
    check_p5_quarantine,
    check_reconciliation,
    check_freeze_manifest,
    check_report_trace,
    check_required_outputs,
    build_acceptance_matrix,
)


def test_negative_p5_quarantine_rejects_2025_date():
    """Verifier must reject any output containing dates >= 2025-01-01."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        diag_dir = tmp_path / "diagnostics"
        diag_dir.mkdir(parents=True)
        
        # Create a valid table first
        valid_df = pd.DataFrame({"date": ["2024-12-02", "2024-12-31"], "value": [1.0, 2.0]})
        valid_df.to_csv(diag_dir / "daily_correlations.csv", index=False)
        passed, msg = check_p5_quarantine(tmp_path)
        assert passed
        
        # Inject an out-of-bounds 2025 date row
        injected_df = pd.DataFrame({"date": ["2024-12-02", "2025-01-02"], "value": [1.0, 2.0]})
        injected_df.to_csv(diag_dir / "daily_correlations.csv", index=False)
        passed, msg = check_p5_quarantine(tmp_path)
        assert not passed
        assert "P5 Quarantine Violation" in msg or "exceeds" in msg


def test_negative_reconciliation_rejects_tampered_fees():
    """Verifier must reject reconciliation when monthly fees do not equal ledger fees."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        
        # Create valid reconciliation
        rec_df = pd.DataFrame([{
            "universe": "US9", "strategy": "A", "cost_bps": 3.0,
            "experiment_id": "EXP_US9_A_3bps",
            "fills_fees_sum": 10960.0, "ledger_fees_sum": 10960.0, "monthly_fees_sum": 10960.0,
            "fees_reconciled": True,
            "w_start_open": 1e6, "w_end_open": 1.1e6,
            "cum_return_telescoping": 0.10, "nav_ratio_telescoping": 0.10,
            "compounding_reconciled": True,
        }])
        rec_df.to_csv(tmp_path / "reconciliation.csv", index=False)
        passed, msg = check_reconciliation(tmp_path)
        assert passed
        
        # Tamper monthly fees to duplicate fees (like in v1 bug)
        rec_df.loc[0, "monthly_fees_sum"] = 21623.0
        rec_df.loc[0, "fees_reconciled"] = False
        rec_df.to_csv(tmp_path / "reconciliation.csv", index=False)
        passed, msg = check_reconciliation(tmp_path)
        assert not passed
        assert "reconciliation failed" in msg.lower() or "fees" in msg.lower()


def test_negative_freeze_manifest_rejects_hash_tampering():
    """Verifier must reject freeze verification if a frozen file's contents are altered."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        out_dir = tmp_path / "outputs"
        out_dir.mkdir(parents=True)
        
        dummy_file = tmp_path / "dummy.py"
        dummy_file.write_text("print('hello')", encoding="utf-8")
        import hashlib
        h = hashlib.sha256(dummy_file.read_bytes()).hexdigest()
        
        manifest = {
            "files": [{"path": "dummy.py", "sha256": h, "bytes": len(dummy_file.read_bytes())}]
        }
        (out_dir / "freeze_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        passed, msg = check_freeze_manifest(out_dir, tmp_path)
        assert passed
        
        # Tamper file contents
        dummy_file.write_text("print('tampered')", encoding="utf-8")
        passed, msg = check_freeze_manifest(out_dir, tmp_path)
        assert not passed
        assert "Freeze hash mismatch" in msg


def test_negative_required_outputs_rejects_missing_tables():
    """Verifier must reject if required tables like factors_long.csv or coverage.csv are missing."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        passed, msg = check_required_outputs(tmp_path)
        assert not passed
        assert "missing" in msg.lower()


def test_negative_acceptance_matrix_reports_real_failures():
    """Acceptance matrix must produce FAIL when checks fail, not hardcoded PASS."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        # Empty directory -> checks will fail
        v_data = {
            "tests": {"passed": 0, "failures": 1, "errors": 0, "skipped": 0},
            "audits_passed": 0,
            "freeze_verification": "FAIL",
            "p5_quarantine": "FAIL",
            "reproducibility": {"performed": False},
        }
        matrix = build_acceptance_matrix(tmp_path, v_data)
        statuses = set(matrix["status"].unique())
        assert "FAIL" in statuses
