"""Candidate packaging script for CF2026 Project 3.

Creates Project3_Review_Bundle.zip and SHA-256 checksum file for ChatGPT review,
and copies standalone report PDF, verification.json, acceptance_matrix.csv, and
VSCODE_REPORT.md to workspace root for quick inspection.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
WORKSPACE_ROOT = ROOT.parent


def sha256_of_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def build_file_manifest(target_dir: Path) -> dict[str, Any]:
    manifest = []
    for p in sorted(target_dir.rglob("*")):
        if p.is_file() and not any(part in p.parts for part in [".venv", "__pycache__", ".git", ".pytest_cache"]):
            manifest.append({
                "path": str(p.relative_to(target_dir)).replace("\\", "/"),
                "bytes": p.stat().st_size,
                "sha256": sha256_of_file(p),
            })
    return {"total_files": len(manifest), "files": manifest}


def main() -> int:
    parser = argparse.ArgumentParser(description="Package Project 3 review bundle")
    parser.add_argument("--review", action="store_true", help="Package review candidate zip")
    parser.add_argument("--out-zip", default="Project3_Review_Bundle.zip", help="Zip output name")
    args = parser.parse_args()

    print("=== CF2026 Project 3: Packaging Review Candidate ===")

    # 1. Build FILE_MANIFEST.json inside Project3
    print("1. Generating FILE_MANIFEST.json...")
    manifest_data = build_file_manifest(ROOT)
    (ROOT / "FILE_MANIFEST.json").write_text(json.dumps(manifest_data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"   Indexed {manifest_data['total_files']} files.")

    # 2. Package ZIP
    zip_path = WORKSPACE_ROOT / args.out_zip
    print(f"2. Creating candidate archive: {zip_path.name}...")

    # Files/folders to exclude
    exclude_dirs = {".venv", "__pycache__", ".git", ".pytest_cache"}
    exclude_files = {zip_path.name, f"{zip_path.name}.sha256.txt"}

    total_packed = 0
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for p in sorted(ROOT.rglob("*")):
            if p.is_dir():
                continue
            if any(part in p.parts for part in exclude_dirs):
                continue
            if p.name in exclude_files:
                continue

            rel_in_zip = Path("Project3") / p.relative_to(ROOT)
            zf.write(p, arcname=str(rel_in_zip).replace("\\", "/"))
            total_packed += 1

    zip_bytes = zip_path.stat().st_size
    zip_sha = sha256_of_file(zip_path)
    print(f"   Packed {total_packed} files into {zip_path.name} ({zip_bytes:,} bytes).")
    print(f"   SHA-256: {zip_sha}")

    # 3. Write SHA256 checksum file
    sha_file = WORKSPACE_ROOT / f"{zip_path.name}.sha256.txt"
    sha_file.write_text(f"{zip_sha}  {zip_path.name}\n", encoding="utf-8")
    print(f"   Wrote checksum file: {sha_file.name}")

    # 4. Copy quick review standalone files to workspace root
    print("3. Staging quick-review artifacts in workspace root...")
    staged = []
    
    pdf_src = ROOT / "outputs" / "report" / "Project3_Report.pdf"
    if pdf_src.exists():
        shutil.copy2(pdf_src, WORKSPACE_ROOT / "Project3_Report.pdf")
        staged.append("Project3_Report.pdf")

    verif_src = ROOT / "outputs" / "verification.json"
    if verif_src.exists():
        shutil.copy2(verif_src, WORKSPACE_ROOT / "verification.json")
        staged.append("verification.json")

    acc_src = ROOT / "outputs" / "acceptance_matrix.csv"
    if acc_src.exists():
        shutil.copy2(acc_src, WORKSPACE_ROOT / "acceptance_matrix.csv")
        staged.append("acceptance_matrix.csv")

    vsc_rep = ROOT / "VSCODE_REPORT.md"
    if vsc_rep.exists():
        shutil.copy2(vsc_rep, WORKSPACE_ROOT / "VSCODE_REPORT.md")
        staged.append("VSCODE_REPORT.md")

    print(f"   Staged: {', '.join(staged)}")

    # 5. Verify ZIP integrity by test-extracting
    print("4. Verifying archive integrity...")
    with zipfile.ZipFile(zip_path, "r") as zf:
        bad_file = zf.testzip()
        if bad_file:
            raise RuntimeError(f"Corrupt file in zip: {bad_file}")
    print("   Archive integrity: 100% OK.")

    print("\n=== Review bundle packaging complete! ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
