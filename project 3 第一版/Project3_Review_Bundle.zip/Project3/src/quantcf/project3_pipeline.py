"""Project 3 Pipeline: Data loading, label alignment, portfolio targets, and broker ledger execution."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

from quantcf.data import load_panel, sha256_file
from quantcf.tsmom import (
    LAMBDA_DEFAULT,
    ANN_FACTOR_VOL,
    calculate_ewma_volatility,
    extract_continuous_daily_returns_before_date,
    get_market_month_ends,
)


def load_universe_data(root: Path, cfg: Dict[str, Any]) -> Dict[str, pd.DataFrame]:
    """Load both CN21 and US9 panels with strict checksum validation."""
    root = Path(root)
    
    # 1. Load CN21 panel
    # We load with full start/end from data config
    cn_cfg = {
        "source": "tushare",
        "start": "2019-01-01",
        "end": "2026-09-18",
        "evaluation_start": "2020-01-01",
        "evaluation_end": "2026-08-31",
        "holding_start": "2020-02-01",
        "holding_end": "2026-08-31",
        "adjustment_reference_date": "2026-09-18",
        "prices_snapshot": cfg["data"]["cn_prices_raw"],
        "adjustment_snapshot": cfg["data"]["cn_adjustments_raw"],
        "manifest": cfg["data"]["cn_source_manifest"],
        "require_manifest": True,
        "min_active_coverage": 0.95,
        "warmup_calendar_days": 420,
        "calendar": "union",
    }
    cn_panel, _, _ = load_panel(root, cn_cfg)
    cn_panel["date"] = pd.to_datetime(cn_panel["date"])
    cn_panel = cn_panel.sort_values(["date", "asset"]).reset_index(drop=True)
    
    # 2. Load US9 panel
    us_manifest_path = root / cfg["data"]["us_source_manifest"]
    us_manifest = json.loads(us_manifest_path.read_text(encoding="utf-8"))
    
    us_list = []
    for item in us_manifest["files"]:
        asset_name = item["asset"]
        fpath = root / cfg["data"]["us_sector_dir"] / f"{asset_name}.csv"
        calc_sha = sha256_file(fpath)
        if calc_sha != item["sha256"]:
            raise ValueError(f"US9 checksum mismatch for {fpath.name}: expected {item['sha256']}, got {calc_sha}")
        
        p = pd.read_csv(fpath)
        # Dates are YYYY-MM-DD
        dt_col = pd.to_datetime(p["Date"].astype(str).str[:10])
        sub = pd.DataFrame({
            "date": dt_col,
            "asset": asset_name,
            "open_adj": p["Open"].astype(float),
            "close_adj": p["Close"].astype(float),
            "high_adj": p["High"].astype(float),
            "low_adj": p["Low"].astype(float),
            "volume": p["Volume"].astype(float),
        })
        # Calculate daily return
        sub["ret_total"] = sub["close_adj"].pct_change(fill_method=None)
        us_list.append(sub)
        
    us_panel = pd.concat(us_list, ignore_index=True).sort_values(["date", "asset"]).reset_index(drop=True)
    
    return {"CN21": cn_panel, "US9": us_panel}


def get_holding_periods(
    calendar_dates: List[pd.Timestamp],
    month_ends: List[pd.Timestamp],
    split_start: pd.Timestamp | str,
    split_end: pd.Timestamp | str,
) -> List[Dict[str, pd.Timestamp]]:
    """Determine non-overlapping monthly holding intervals strictly contained in [split_start, split_end].
    
    A holding period is defined by:
    - formation_date: month-end t
    - entry_date: first trading day strictly after t
    - exit_date: first trading day strictly after t+1
    
    The condition is:
    entry_date >= split_start and exit_date <= split_end.
    """
    cal_dates = sorted(set(pd.to_datetime(calendar_dates)))
    m_ends = sorted(set(pd.to_datetime(month_ends)))
    s_start = pd.to_datetime(split_start)
    s_end = pd.to_datetime(split_end)
    
    periods = []
    for i, t in enumerate(m_ends):
        if i + 1 >= len(m_ends):
            break
        next_m = m_ends[i + 1]
        
        # entry date
        entries = [d for d in cal_dates if d > t]
        if not entries:
            continue
        entry_d = entries[0]
        
        # exit date
        exits = [d for d in cal_dates if d > next_m]
        if not exits:
            continue
        exit_d = exits[0]
        
        if entry_d >= s_start and exit_d <= s_end:
            periods.append({
                "formation_date": t,
                "entry_date": entry_d,
                "next_formation_date": next_m,
                "exit_date": exit_d,
            })
            
    return periods


def compute_holding_labels(
    panel: pd.DataFrame,
    periods: List[Dict[str, pd.Timestamp]],
) -> pd.DataFrame:
    """Compute open-to-open holding labels: y(i, t) = open(exit) / open(entry) - 1."""
    piv_open = panel.pivot(index="date", columns="asset", values="open_adj").sort_index()
    
    records = []
    for p in periods:
        t = p["formation_date"]
        entry = p["entry_date"]
        exit_d = p["exit_date"]
        
        if entry not in piv_open.index or exit_d not in piv_open.index:
            continue
        
        row_entry = piv_open.loc[entry]
        row_exit = piv_open.loc[exit_d]
        
        for asset in piv_open.columns:
            p_en = row_entry.get(asset, np.nan)
            p_ex = row_exit.get(asset, np.nan)
            if not np.isnan(p_en) and not np.isnan(p_ex) and p_en > 0 and p_ex > 0:
                ret = float(p_ex / p_en - 1.0)
                records.append({
                    "formation_date": t,
                    "entry_date": entry,
                    "exit_date": exit_d,
                    "asset": asset,
                    "holding_return": ret,
                })
                
    return pd.DataFrame(records)


def assign_tercile_memberships(scores: pd.Series) -> Dict[str, Tuple[float, float, float]]:
    """Assign fractional memberships in [Bottom T1, Middle T2, Top T3] with exact tie-handling.
    
    Returns a dict mapping asset -> (m_T1, m_T2, m_T3) each in [0, 1].
    The sum of memberships for each group across all assets is exactly N/3.
    """
    valid = scores.dropna()
    N = len(valid)
    if N == 0:
        return {}
    
    mass_per_group = N / 3.0
    # Group intervals in continuous rank space [0, N]:
    # T1: [0, N/3]
    # T2: [N/3, 2N/3]
    # T3: [2N/3, N]
    
    # Sort assets by score ascending
    # Group assets by unique score to handle ties exactly
    unique_scores = sorted(valid.unique())
    
    # Track current cumulative mass
    cum = 0.0
    memberships = {}
    
    for val in unique_scores:
        ties = valid[valid == val].index.tolist()
        k = len(ties)
        start_rank = cum
        end_rank = cum + k
        cum = end_rank
        
        # Overlaps with T1, T2, T3
        # T1: [0, N/3]
        o_t1 = max(0.0, min(end_rank, mass_per_group) - max(start_rank, 0.0))
        # T2: [N/3, 2N/3]
        o_t2 = max(0.0, min(end_rank, 2.0 * mass_per_group) - max(start_rank, mass_per_group))
        # T3: [2N/3, N]
        o_t3 = max(0.0, min(end_rank, N) - max(start_rank, 2.0 * mass_per_group))
        
        # Per asset membership
        m1 = o_t1 / k
        m2 = o_t2 / k
        m3 = o_t3 / k
        
        for asset in ties:
            memberships[asset] = (m1, m2, m3)
            
    return memberships


def generate_portfolio_target_weights(
    df_factors: pd.DataFrame,
    periods: List[Dict[str, pd.Timestamp]],
    daily_panel: pd.DataFrame,
    calendar_dates: List[pd.Timestamp],
    strategy_mode: str,
    budget: float = 0.99,
    min_assets: int = 6,
    vol_decay: float = LAMBDA_DEFAULT,
    vol_ann_factor: float = ANN_FACTOR_VOL,
    min_vol_days: int = 252,
) -> pd.DataFrame:
    """Generate target portfolio weights for each formation date / entry date.
    
    Strategy modes:
    - 'A': Top tercile of factor A, weighted by inverse EWMA vol
    - 'B': Top tercile of factor B (F1), weighted by inverse EWMA vol
    - 'C': Top tercile of factor C (Combo), weighted by inverse EWMA vol
    - 'F2': Top tercile of factor F2, weighted by inverse EWMA vol
    - 'F3': Top tercile of factor F3, weighted by inverse EWMA vol
    - 'A0': Positive momentum sign assets from A0, weighted by inverse EWMA vol
    - 'passive_equal': Equal weight among all qualified assets (budget 0.99)
    - 'passive_inv_vol': Inverse volatility weight among all qualified assets (budget 0.99)
    """
    piv_ret = daily_panel.pivot(index="date", columns="asset", values="ret_total").sort_index()
    
    targets = []
    
    for p in periods:
        t = p["formation_date"]
        entry = p["entry_date"]
        
        sub_factors = df_factors[df_factors["formation_date"] == t].set_index("asset")
        if len(sub_factors) < min_assets:
            continue
        
        qual_assets = sub_factors.index.tolist()
        
        # Compute EWMA volatilities at date t
        vols = {}
        for asset in qual_assets:
            if asset not in piv_ret.columns:
                continue
            s_ret = piv_ret[asset].loc[:t].dropna()
            continuous_rets = extract_continuous_daily_returns_before_date(s_ret, t, max_days=min_vol_days)
            if len(continuous_rets) < min_vol_days:
                continue
            vol = calculate_ewma_volatility(continuous_rets, decay=vol_decay, min_days=min_vol_days, ann_factor=vol_ann_factor)
            if not np.isnan(vol) and vol > 1e-6:
                vols[asset] = vol
                
        # Eligible assets must have valid volatility
        valid_assets = [a for a in qual_assets if a in vols]
        if len(valid_assets) < min_assets:
            continue
        
        # Determine strategy weights
        if strategy_mode in ["A", "B", "C", "F2", "F3"]:
            scores = sub_factors.loc[valid_assets, strategy_mode]
            if scores.isna().all():
                continue
            memberships = assign_tercile_memberships(scores)
            
            # Group 3 is Top Tercile
            raw_weights = {}
            for asset in valid_assets:
                m_top = memberships[asset][2]
                if m_top > 0:
                    raw_weights[asset] = m_top / vols[asset]
                    
            tot = sum(raw_weights.values())
            if tot > 0:
                for asset, rw in raw_weights.items():
                    targets.append({
                        "signal_date": t,
                        "execution_date": entry,
                        "asset": asset,
                        "target_weight": float((rw / tot) * budget),
                    })
                    
        elif strategy_mode == "A0":
            # Positive momentum signs only
            raw_signs = sub_factors.loc[valid_assets, "a0_raw"]
            pos_assets = [a for a in valid_assets if raw_signs.get(a, 0.0) > 0]
            if pos_assets:
                inv_vols = {a: 1.0 / vols[a] for a in pos_assets}
                tot = sum(inv_vols.values())
                for a, iv in inv_vols.items():
                    targets.append({
                        "signal_date": t,
                        "execution_date": entry,
                        "asset": a,
                        "target_weight": float((iv / tot) * budget),
                    })
                    
        elif strategy_mode == "passive_equal":
            n_val = len(valid_assets)
            for a in valid_assets:
                targets.append({
                    "signal_date": t,
                    "execution_date": entry,
                    "asset": a,
                    "target_weight": float(budget / n_val),
                })
                
        elif strategy_mode == "passive_inv_vol":
            inv_vols = {a: 1.0 / vols[a] for a in valid_assets}
            tot = sum(inv_vols.values())
            for a, iv in inv_vols.items():
                targets.append({
                    "signal_date": t,
                    "execution_date": entry,
                    "asset": a,
                    "target_weight": float((iv / tot) * budget),
                })
        else:
            raise ValueError(f"Unknown strategy mode: {strategy_mode}")
            
    df_targets = pd.DataFrame(targets)
    if df_targets.empty:
        return pd.DataFrame(columns=["signal_date", "execution_date", "asset", "target_weight"])
    return df_targets.sort_values(["execution_date", "asset"]).reset_index(drop=True)


def execute_broker_simulation(
    panel: pd.DataFrame,
    targets: pd.DataFrame,
    periods: List[Dict[str, pd.Timestamp]],
    calendar_dates: List[pd.Timestamp],
    cost_bps: float = 3.0,
    initial_cash: float = 1_000_000.0,
) -> Dict[str, Any]:
    """Execute target weights at next-open using self-financing cash account with complete ledger and audit.
    
    Generates orders, fills, holdings, ledger, and monthly returns.
    """
    fee_rate = cost_bps / 10_000.0
    piv_open = panel.pivot(index="date", columns="asset", values="open_adj").sort_index()
    piv_close = panel.pivot(index="date", columns="asset", values="close_adj").sort_index()
    
    # All active dates during the trading periods
    if not periods:
        raise ValueError("No holding periods provided for backtest")
        
    start_date = periods[0]["entry_date"]
    end_date = periods[-1]["exit_date"]
    all_dates = [d for d in calendar_dates if start_date <= d <= end_date]
    
    # State tracking
    cash = initial_cash
    current_shares = {asset: 0.0 for asset in piv_open.columns}
    
    orders_list = []
    fills_list = []
    holdings_list = []
    ledger_list = []
    
    # Group targets by execution date
    targets_by_entry = {}
    if not targets.empty:
        for entry_d, grp in targets.groupby("execution_date"):
            targets_by_entry[pd.to_datetime(entry_d)] = grp.set_index("asset")["target_weight"].to_dict()
            
    prev_equity = initial_cash
    
    for d in all_dates:
        # Check if today is an entry date for a rebalance
        is_rebalance_day = d in targets_by_entry
        target_weights = targets_by_entry.get(d, None)
        
        buy_notional = 0.0
        sell_notional = 0.0
        daily_fees = 0.0
        
        if is_rebalance_day and target_weights is not None:
            # Rebalance at today's open price
            # 1. Calculate portfolio equity at open
            open_prices = {asset: piv_open.loc[d, asset] for asset in piv_open.columns if not np.isnan(piv_open.loc[d, asset])}
            portfolio_val_at_open = cash + sum(current_shares[a] * open_prices.get(a, 0.0) for a in current_shares)
            
            # 2. Determine target shares
            target_shares = {}
            for asset, tw in target_weights.items():
                p_op = open_prices.get(asset, np.nan)
                if not np.isnan(p_op) and p_op > 0:
                    target_shares[asset] = (portfolio_val_at_open * tw) / p_op
                    
            # All other assets target 0
            for asset in current_shares:
                if asset not in target_shares:
                    target_shares[asset] = 0.0
                    
            # 3. Execute sells first
            for asset, t_sh in target_shares.items():
                cur_sh = current_shares[asset]
                diff = t_sh - cur_sh
                if diff < -1e-8:
                    sell_qty = -diff
                    p_op = open_prices[asset]
                    val = sell_qty * p_op
                    fee = val * fee_rate
                    cash += (val - fee)
                    sell_notional += val
                    daily_fees += fee
                    current_shares[asset] = t_sh
                    
                    orders_list.append({"date": d, "asset": asset, "side": "SELL", "quantity": sell_qty, "price": p_op})
                    fills_list.append({"date": d, "asset": asset, "side": "SELL", "quantity": sell_qty, "price": p_op, "fee": fee})
                    
            # 4. Execute buys next
            for asset, t_sh in target_shares.items():
                cur_sh = current_shares[asset]
                diff = t_sh - cur_sh
                if diff > 1e-8:
                    buy_qty = diff
                    p_op = open_prices[asset]
                    val = buy_qty * p_op
                    fee = val * fee_rate
                    
                    # Cash protection
                    if val + fee > cash:
                        # Scale down buy quantity so cash is never negative
                        val = max(0.0, cash / (1.0 + fee_rate))
                        buy_qty = val / p_op
                        fee = val * fee_rate
                        
                    cash -= (val + fee)
                    buy_notional += val
                    daily_fees += fee
                    current_shares[asset] = cur_sh + buy_qty
                    
                    orders_list.append({"date": d, "asset": asset, "side": "BUY", "quantity": buy_qty, "price": p_op})
                    fills_list.append({"date": d, "asset": asset, "side": "BUY", "quantity": buy_qty, "price": p_op, "fee": fee})
                    
        # Mark to market at close of day d
        close_prices = {asset: piv_close.loc[d, asset] for asset in piv_close.columns if not np.isnan(piv_close.loc[d, asset])}
        holdings_mv = 0.0
        for asset, sh in current_shares.items():
            if sh > 1e-8:
                p_cl = close_prices.get(asset, np.nan)
                mv = sh * (p_cl if not np.isnan(p_cl) else 0.0)
                holdings_mv += mv
                holdings_list.append({"date": d, "asset": asset, "shares": sh, "close_price": p_cl, "market_value": mv})
                
        equity = cash + holdings_mv
        daily_ret = float(equity / prev_equity - 1.0) if prev_equity > 0 else 0.0
        prev_equity = equity
        
        ledger_list.append({
            "date": d,
            "cash": cash,
            "holdings_value": holdings_mv,
            "equity": equity,
            "daily_return": daily_ret,
            "buy_notional": buy_notional,
            "sell_notional": sell_notional,
            "fees_paid": daily_fees,
            "cash_ratio": cash / equity if equity > 0 else 1.0,
            "gross_exposure": holdings_mv / equity if equity > 0 else 0.0,
        })
        
    df_orders = pd.DataFrame(orders_list)
    df_fills = pd.DataFrame(fills_list)
    df_holdings = pd.DataFrame(holdings_list)
    df_ledger = pd.DataFrame(ledger_list)
    
    # Audit checks
    cash_min = df_ledger["cash"].min()
    gross_max = df_ledger["gross_exposure"].max()
    audit_passed = (cash_min >= -1e-6) and (gross_max <= 1.0 + 1e-4)
    
    audit_report = {
        "passed": bool(audit_passed),
        "checks": {
            "cash_non_negative": bool(cash_min >= -1e-6),
            "no_leverage_le_100pct": bool(gross_max <= 1.0 + 1e-4),
            "conservation_of_equity": bool(np.max(np.abs(df_ledger["cash"] + df_ledger["holdings_value"] - df_ledger["equity"])) < 1e-6),
            "orders_match_fills": len(df_orders) == len(df_fills),
        },
        "initial_cash": initial_cash,
        "final_cash": float(cash),
        "final_equity": float(df_ledger["equity"].iloc[-1]),
        "total_fees_paid": float(df_ledger["fees_paid"].sum()),
    }
    
    # Calculate monthly period net returns from holding periods
    monthly_ret_records = []
    df_ledger = df_ledger.set_index("date")
    for p in periods:
        en = p["entry_date"]
        ex = p["exit_date"]
        if en in df_ledger.index and ex in df_ledger.index:
            # We measure compound return between the entry date open (when trades filled) and exit date open
            # Equivalently, from ledger equity at previous close to exit date close, or product of 1 + daily_return
            sub_leg = df_ledger.loc[en:ex]
            if len(sub_leg) > 1:
                # Return over the holding interval
                ret_interval = float(np.prod(1.0 + sub_leg["daily_return"].iloc[1:].values) - 1.0)
                turnover = float((sub_leg["buy_notional"].sum() + sub_leg["sell_notional"].sum()) / sub_leg["equity"].iloc[0])
                fees = float(sub_leg["fees_paid"].sum())
                monthly_ret_records.append({
                    "formation_date": p["formation_date"],
                    "entry_date": en,
                    "exit_date": ex,
                    "net_return": ret_interval,
                    "turnover": turnover,
                    "fees": fees,
                })
                
    df_monthly_returns = pd.DataFrame(monthly_ret_records)
    
    # Performance summary metrics
    if not df_monthly_returns.empty:
        r_series = df_monthly_returns["net_return"]
        n_m = len(r_series)
        ann_mean = float(r_series.mean() * 12.0)
        ann_vol = float(r_series.std(ddof=1) * np.sqrt(12.0)) if n_m > 1 else 0.0
        sharpe = float(ann_mean / ann_vol) if ann_vol > 1e-6 else np.nan
        
        # Max drawdown
        cum_wealth = np.cumprod(1.0 + r_series.values)
        peak = np.maximum.accumulate(cum_wealth)
        dd = (cum_wealth - peak) / peak
        max_dd = float(np.min(dd)) if len(dd) > 0 else 0.0
        calmar = float(ann_mean / abs(max_dd)) if abs(max_dd) > 1e-6 else np.nan
        win_rate = float((r_series > 0).mean())
        
        summary_metrics = {
            "n_months": n_m,
            "ann_mean": ann_mean,
            "ann_vol": ann_vol,
            "sharpe": sharpe,
            "max_drawdown": max_dd,
            "calmar": calmar,
            "win_rate": win_rate,
            "total_turnover": float(df_monthly_returns["turnover"].sum()),
            "total_fees": float(df_monthly_returns["fees"].sum()),
            "cost_bps": cost_bps,
        }
    else:
        summary_metrics = {}
        
    return {
        "orders": df_orders,
        "fills": df_fills,
        "holdings": df_holdings,
        "ledger": df_ledger.reset_index(),
        "monthly_returns": df_monthly_returns,
        "audit": audit_report,
        "summary": summary_metrics,
    }
