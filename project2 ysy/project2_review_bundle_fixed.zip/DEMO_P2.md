# Project 2 演示讲解指南 (DEMO_P2)

**项目名称**: Time Series Momentum: Method Replication on an ETF Sample and a Multi-horizon Signal Extension  
**汇报人**: 袁思扬 (学号: 12411852)  
**汇报时长**: 建议 5–8 分钟（根据课堂要求微调）  
**配套演示资料**: 
- 完整英文报告: `outputs_p2_fixed/report_en.pdf` (或 `report_en.html`)
- 中文研究摘要: `outputs_p2_fixed/summary_zh.md`
- 核心指标汇总表: `outputs_p2_fixed/strategy_summary.csv`
- 对比图表集: `outputs_p2_fixed/figures/`
- 执行明细与审计: `outputs_p2_fixed/backtests/`
- 审查回复说明: `P2_FIX_RESPONSE.md`

---

## 演示推荐顺序与演讲要点

### 1. 原问题与目标图 (0:00 - 1:00)
- **核心问题**: 资产自身过去 12 个月的收益方向，能否在本项目包含 21 只 ETF 的替代样本（2019–2026）上形成有意义的趋势策略？
- **基准论文**: Moskowitz, Ooi & Pedersen (2012) *Time Series Momentum*, JFE。
- **锚定目标图**:
  - **主目标 (Fig. 2 上部)**: 检验单资产经事前波动率缩放后，正夏普比率资产的分布与比例（原文 58/58 全球期货合约均为正，其中 52 只在 5% 水平显著）。
  - **辅助目标 (Fig. 3)**: 比较同风险预算下，分散化时间序列动量策略相对被动做多（Passive Long）的累计超额表现。

### 2. 核心方法与一个小样本手算核算 (1:00 - 2:30)
- **核心公式**:
  - 12 个月动量符号: $s^{(12)}_{i,m} = \operatorname{sign}(P^{adj}_{i,m} / P^{adj}_{i,m-12} - 1)$
  - 有限历史 EWMA 方差: 衰减 $\lambda = 60/61$，连续 $\ge 252$ 日收益，权重 $a_j = \frac{(1-\lambda)\lambda^j}{1-\lambda^n}$，年化系数 261。
  - 论文研究权重: $w^{TS}_{i,m} = \frac{1}{N_m} s^{(12)}_{i,m} \frac{0.40}{\sigma_{i,m}}$
- **独立手算核对展示** (`docs/project2/method_checks.md`):
  - 举例展示衰减 $\lambda=0.5$、收益 $[0.01, -0.01, 0.02]$ 的解析方差 $3/17500 \approx 0.00017143$。
  - 举例展示两资产波动率 20% 与 10%、动量 $+1$ 与 $-1$ 时，权重精准为 $+1.0$ 与 $-2.0$，下一期收益分别 $+5\%$ 与 $-2\%$ 时组合收益精确为 $+9.0\%$。

### 3. Project 1 接入位置与执行约束 (2:30 - 3:30)
- **复用部分**: `data.py` 数据复权与日历、`backtest.py` 账本经纪商（非负持仓、无借贷、次日开盘价撮合与手续费扣除）。
- **新增模块**: 
  - `src/quantcf/tsmom.py`: 纯函数计算月末动量、EWMA 波动率与多期限信号。
  - `src/quantcf/research_backtest.py`: 理论多空月频研究模式（形成资产资格与未来收益完全解耦）。
  - `src/quantcf/portfolio.py::generate_tsmom_long_cash_targets()`: 真实执行模式，逆波动率预算分配 $b_{i,m} = 0.99 \frac{1/\sigma_i}{\sum 1/\sigma_j}$，负信号预算留存现金，全负或不足 6 只资产时安全清仓。

### 4. 原文结果 vs 本次复现结果对照 (3:30 - 5:00)
- **单资产夏普分布 (展示 `fig2_single_asset_sharpe.png`)**:
  - 在 21 只 ETF 替代样本中，**17 只资产（81.0%）获得正夏普比率**，均值达到 0.454。
  - 国债、城投债、十年国债（夏普 1.54–1.65）、黄金（1.18）及纳指/标普（0.88）动量极其强劲；周期性与金融权重股（券商、地产、上证50）受震荡反复折损，夏普为负。
- **组合累计表现 (展示 `fig3_cumulative_comparison.png`)**:
  - R1 (12M TSMOM) 理论年化收益 18.91%，夏普 0.792，胜率 72.15%。
  - 但被动做多（R2）年化收益 24.53%，夏普 0.986。
  - **原因解释**: 原文覆盖全球 58 种无牛市偏向的多空期货；本项目中债市与黄金经历了持续单边大牛市，被动多头充分享受了久期与抗通胀红利，而时序动量在权益市场遭遇多次政策驱动的急跌急涨反转，做空端产生反向拖累。
  - **AQR 官方公开因子复算对比**: 300 个月官方数据复算 Sharpe 1.385、年化收益 17.08%，严格对应 Table 4 报出的 1.38 与 17.1%。

### 5. 关键差异归因与自主扩展 (5:00 - 6:30)
- **核心归因实验**:
  - **做空限制桥接 (Bridge vs R1)**: 当剔除空头仅保留多头与现金时，夏普比率跃升至 1.446，最大回撤大幅缩减至 -12.10%。
  - **资产类别方差分解**: 协方差分解 $\operatorname{Cov}(r_c, R)/\operatorname{Var}(R)$ 证实境内权益贡献了组合 **84.76%** 的总方差风险；若仅在 3 只宽基股指（510050, 510300, 510500）上跑动量，夏普仅 0.052，回撤达 -79.80%。
  - **252 日滚动方差估计器**: 真实 252 日滚动样本波动率下策略夏普为 0.730（EWMA 为 0.792），EWMA 对近期波动变化反应更为敏锐。
- **自主扩展：多期限趋势组合 (R4 / T2，展示 `fig_multi_horizon_comparison.png`)**:
  - 固定 3、6、12 个月等权复合 ($a = (s_3 + s_6 + s_{12})/3$)，不做样本内调参。
  - **研究层**: 波动率由 23.88% 降至 22.17%，最大回撤由 -35.73% 改善至 -33.74%。
  - **执行层 (T2 vs T1，严格 1599 个交易日)**: 在受约束真实账本下，**夏普比率由 1.303 提升至 1.350，最大回撤由 -4.25% 缩小至 -3.38%**；换手率由 1.43x 升至 2.35x，手续费增加 1997 元，展现明确的收益风险权衡。

### 6. 可复现运行入口 (6:30 - 7:00)
- 现场演示一行命令跑通全部流程：
  ```powershell
  uv run --locked pytest
  uv run --locked python run_project2.py --config config/project2_tsmom.json --out outputs_p2_fixed --offline
  uv run --locked python build_report_project2.py --out outputs_p2_fixed
  ```

